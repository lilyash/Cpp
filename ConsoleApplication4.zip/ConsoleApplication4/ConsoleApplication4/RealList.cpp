#include "stdafx.h"
#include "RealList.h"


RealList::ListIterator::ListIterator(RealList * theList)
{
	List = theList;
	index = 0;
	now = List->first;
}

RealList::ListIterator::ListIterator() {}

void RealList::ListIterator::StartWork()
{
	index = 0;
	now = List->first;
}

int RealList::ListIterator::GetNowElement() const
{
	if (index == 0) {
		throw BufferException();
	}
	return now->data;
}

void RealList::ListIterator::ShiftNextElement()
{
	now = now->next;
	index++;
	index = index%List->size;
}

bool RealList::ListIterator::AllIter() const
{
	if (now->next = List->first) {
		return true;
	}
	return false;
}

Node * RealList::ListIterator::getNow() const
{
	return now;
}

RealList::RealList()
{
	first = new Node;
	first->data = 0;
	first->next = first;
	first->prev = first;
	size = 0;
}


RealList::~RealList()
{
	if (size > 0) {
		MakeEmpty();
	}
	delete first;
}

RealList::RealList(const RealList & copy)
{
	first = new Node;
	first->data = 0;
	first->next = first;
	size = copy.size;
	Node *buf = copy.first->next;
	for (int i = 0; i < size; i++) {
		Node *temp = new Node;
		temp->data = buf->data;
		temp->next = first->next;
		first->prev = first;
		first->next = temp;
		first = temp;
		buf = buf->next;
	}
	first->next->prev = first;
	first = first->next;
}

RealList::RealList(RealList && copy)
{
	std::swap(first, copy.first);
	size = copy.size; 
}

RealList & RealList::operator=(const RealList & obj)
{
	if (this == &obj) {
		return *this;
	}
	if (size > 0) {
		MakeEmpty();
	}
	size = obj.size;
	Node *buf = obj.first->next;
	for (int i = 0; i < this->size; i++) {
		Node *temp = new Node;
		temp->data = buf->data;
		temp->next = first->next;
		temp->prev = first;
		first->next = temp;
		first = temp;
		buf = buf->next;
	}
	first->next->prev = first;
	first = first->next;
	return *this;
}

RealList & RealList::operator=( RealList && obj)
{
	std::swap(first, obj.first);
	size = obj.size;
	return *this;
}

void RealList::InsertElement(int x, Iterator & itr)
{
	Node *temp = new Node;
	temp->data = x;
	temp->next = (itr.getNow())->next;
	temp->prev = (itr.getNow());
	(itr.getNow())->next->prev = temp;
	(itr.getNow())->next = temp;
	size++;
}

void RealList::DeleteElement(Iterator & itr)
{
	if (size == 0) {
		throw ListEmptyException();
	}
	if (itr.getNow() == first) {
		throw BufferException();
	}
	Node *nowElem = itr.getNow();
	itr.ShiftNextElement();
	Node *temp = nowElem->next;
	nowElem->next->prev = nowElem->prev;
	nowElem->prev->next = nowElem->next;
	delete (nowElem);
	size--;
}

Iterator * RealList::FirstEnrty(int x)
{
	ListIterator* res = new ListIterator(this);
	for (int i = 0; i < size; i++) {
		if (res->GetNowElement() == x) {
			return res;
		}
		res->ShiftNextElement();
	}
	throw NoElemException();
}

void RealList::MakeEmpty()
{
	first = first->next;
	for (int i = 0; i < size; i++) {
		first = first->next;
		delete first->prev;
	}
	first->next = first;
	first->prev = first;
	size = 0;
}

bool RealList::IsEmpty() {
	return (size == 0);
}

int RealList::GetAmt()
{
	return size;
}

Iterator * RealList::FirstElement()
{
	return new ListIterator(this);
}
