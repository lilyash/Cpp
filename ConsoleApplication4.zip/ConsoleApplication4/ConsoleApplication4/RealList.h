#pragma once
#include"stdafx.h"
#include"List.h"
#include"iostream"

struct ListEmptyException {};
struct BufferException {};
struct NoElemException{};

class RealList:public List{
private:
	Node *first;
	int size;

public:
	class ListIterator : public Iterator {
	private:
		int index;
		RealList *List;
		Node *now;
	public:
		ListIterator(RealList *theList);
		ListIterator();
		void StartWork();
		int GetNowElement() const;
		void ShiftNextElement();
		bool AllIter() const;
		Node* getNow() const;
	};

	RealList();
	~RealList();
	RealList(const RealList& copy);
	RealList(RealList&& copy);
	RealList& operator=(const RealList & obj);
	RealList& operator=( RealList && obj);
	void InsertElement(int x, Iterator& itr);
	void DeleteElement(Iterator& itr);
	Iterator* FirstEnrty(int x);
	void MakeEmpty();
	bool IsEmpty();
	int GetAmt();
	Iterator* FirstElement();
};

