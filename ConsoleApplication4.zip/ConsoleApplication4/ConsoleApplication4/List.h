#pragma once
#include"Iterator.h"

class List {
public:
	virtual void InsertElement(int x, Iterator& itr) = 0;
	virtual void DeleteElement(Iterator& itr) = 0;
	virtual Iterator* FirstEnrty(int x) = 0;
	virtual void MakeEmpty() = 0;
	virtual bool IsEmpty() = 0;
	virtual int GetAmt() = 0;
	virtual Iterator* FirstElement() = 0;
};
