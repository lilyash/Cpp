#pragma once
#include "stdafx.h"

struct EndOfIterator{};

typedef int TElem;
struct Node {
	int data;
	Node* next;
	Node* prev;
};

class Iterator
{
public:
	virtual void StartWork() = 0;
	virtual int GetNowElement() const = 0;
	virtual void ShiftNextElement() = 0;
	virtual bool AllIter() const = 0;
	virtual Node* getNow() const = 0;

};
